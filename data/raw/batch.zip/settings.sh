#!/bin/bash
# A single numerical job at a time keeps these timing runs isolated.
if [ -z "${PYTHON:-}" ]; then
  for cand in python3 python; do
    if command -v "$cand" >/dev/null 2>&1 && "$cand" -c "import sys,numpy,gurobipy; assert sys.version_info >= (3,10)" >/dev/null 2>&1; then
      PYTHON="$cand"
      break
    fi
  done
fi
: "${PYTHON:=python3}"
export PYTHON
export GRB_LICENSE_FILE="${GRB_LICENSE_FILE:-$HOME/gurobi.lic}"
export WORKERS=1
export THREADS="${THREADS:-1}"
export TIMELIMIT="${TIMELIMIT:-3600}"
export MAX_HOURS="${MAX_HOURS:-24}"
export WORKER_MEMORY_MB="${WORKER_MEMORY_MB:-3072}"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
