"""Tests for notifications, refresh orchestration and detached launch."""
import csv
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import batch
import workstation as ws


class RefreshTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name)
        for name in ('logs', 'results', 'tasks'):
            (self.root/name).mkdir()
        (self.root/'NTFY_TOPIC.txt').write_text('test-topic')
        for group in batch.GROUPS:
            method = 'brute' if group=='brute_small' else ('dp' if group.startswith('dp') else 'milp')
            (self.root/'tasks'/(group+'.txt')).write_text('%s n=3 T=1 top=s\n' % method)
        self.patches = [patch.object(batch,'ROOT',self.root), patch.object(ws,'ROOT',self.root)]
        for item in self.patches:
            item.start()

    def tearDown(self):
        for item in reversed(self.patches):
            item.stop()
        self.directory.cleanup()

    def test_notification_post_and_delivery_record(self):
        with patch.object(batch.urllib.request, 'urlopen') as send:
            send.return_value.__enter__.return_value.status = 200
            self.assertTrue(batch.notify('Run started'))
        request = send.call_args.args[0]
        self.assertEqual(request.full_url, 'https://ntfy.sh/test-topic')
        self.assertEqual(request.data, b'Run started')
        self.assertEqual(send.call_args.kwargs['timeout'], 5)
        self.assertTrue(json.loads((self.root/'notifications.jsonl').read_text())['delivered'])

    def test_network_failure_does_not_abort_computation(self):
        with patch.object(batch.urllib.request, 'urlopen', side_effect=OSError('offline')):
            self.assertFalse(batch.notify('Still running'))
        self.assertIn('offline', (self.root/'notifications.jsonl').read_text())

    def test_progress_never_counts_population_as_completed_sweep(self):
        group = 'milp_n6'
        directory = self.root/'results'/group
        directory.mkdir()
        task = next(iter(ws.task_ids(self.root/'tasks'/(group+'.txt'))))
        (directory/'part_000.csv').write_text('method,task,status\nmilp-m,%s,OPTIMAL\n' % task)
        self.assertEqual(batch.progress()[group], [0,1])
        with (directory/'part_000.csv').open('a') as f:
            f.write('milp,%s,FEASIBLE\n' % task)
        self.assertEqual(batch.progress()[group], [0,1])
        with (directory/'part_000.csv').open('a') as f:
            f.write('milp,%s,OPTIMAL\n' % task)
        self.assertEqual(batch.progress()[group], [1,1])

    def test_changed_input_is_rejected(self):
        (self.root/'manifest.json').write_text(json.dumps({'NTFY_TOPIC.txt':'wrong'}))
        with self.assertRaisesRegex(RuntimeError, 'Package file changed'):
            batch.manifest_check()

    def fake_run(self, failure=None, complete=True):
        cfg = dict(WORKERS=2, THREADS=1, WORKER_MEMORY_MB=128, TIMELIMIT=10, MAX_HOURS=1)
        counts = {name:[1 if complete else 0,1] for name in batch.GROUPS}
        calls = []
        def execute(jobs, settings, deadline, cancelled):
            calls.extend(jobs)
            self.assertEqual(settings['WORKERS'], 1)
            if failure:
                raise failure
        with patch.object(ws,'configuration',return_value=cfg), \
             patch.object(ws,'execute',side_effect=execute), \
             patch.object(batch,'manifest_check'), patch.object(batch,'notify'), \
             patch.object(batch,'progress',return_value=counts), patch.object(signal,'signal'):
            result = batch.run()
        return result, json.loads((self.root/'run.json').read_text()), calls

    def test_success_runs_large_dp_after_small_jobs_and_audits(self):
        code, state, calls = self.fake_run()
        self.assertEqual((code,state['status']), (0,'COMPLETED'))
        labels = [name for name,_ in calls]
        self.assertLess(labels.index('milp_n6_0'), labels.index('dp_large_0'))
        self.assertEqual(labels[-1], 'audit')
        commands = [command for label,command in calls if label.endswith('_0')]
        self.assertTrue(all('--retry-feasible' in command for command in commands))

    def test_worker_failure_cannot_be_success(self):
        code,state,_ = self.fake_run(RuntimeError('memory limit'))
        self.assertEqual((code,state['status']), (1,'FAILED'))
        self.assertIn('memory limit',state['reason'])

    def test_unresolved_output_is_incomplete(self):
        code,state,_ = self.fake_run(complete=False)
        self.assertEqual((code,state['status']), (2,'INCOMPLETE'))

    def test_stop_is_reported(self):
        code,state,_ = self.fake_run(InterruptedError('Stop requested'))
        self.assertEqual((code,state['status']), (1,'STOPPED'))

    def test_detached_launch_survives_launching_process_exit(self):
        package = str(Path(__file__).resolve().parent)
        helper = self.root/'helper.py'
        helper.write_text('import json,os,pathlib,time\n'
            'pathlib.Path("child.json").write_text(json.dumps(dict(pid=os.getpid(),sid=os.getsid(0),'
            'stdin=os.read(0,1).decode())))\ntime.sleep(20)\n')
        code = ('import sys,pathlib,os; sys.path.insert(0,sys.argv[1]); import batch,workstation; '
                'batch.ROOT=pathlib.Path(sys.argv[2]); workstation.ROOT=batch.ROOT; '
                'batch.__file__=str(batch.ROOT/"helper.py"); os.chdir(batch.ROOT); batch.launch()')
        child_pid = None
        try:
            subprocess.run([sys.executable,'-c',code,package,str(self.root)],
                           check=True,capture_output=True,timeout=5)
            data = json.loads((self.root/'child.json').read_text())
            child_pid = data['pid']
            self.assertEqual(data['sid'],child_pid)
            self.assertEqual(data['stdin'],'')
            os.kill(child_pid,0)  # detached child survived its launching process
        finally:
            if child_pid:
                try:
                    os.killpg(child_pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass


if __name__ == '__main__':
    unittest.main()
