"""Linux supervisor for the self-contained, resource-limited final run."""
import argparse
import csv
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
GIB = 1024 ** 3


def configuration():
    limits = {'WORKERS': (2, 2), 'THREADS': (2, 2),
              'TIMELIMIT': (3600, 14400), 'MAX_HOURS': (24, 24),
              'WORKER_MEMORY_MB': (3072, 3072)}
    result = {}
    for name, (default, maximum) in limits.items():
        try:
            value = int(os.environ.get(name, default))
        except ValueError:
            raise ValueError('%s must be an integer' % name)
        if not 1 <= value <= maximum:
            raise ValueError('%s must be between 1 and %d' % (name, maximum))
        result[name] = value
    return result


def available_memory():
    for line in Path('/proc/meminfo').read_text().splitlines():
        if line.startswith('MemAvailable:'):
            return int(line.split()[1]) * 1024
    raise RuntimeError('Cannot read MemAvailable; refusing an unmonitored run')


def node_size():
    total = 0
    for path in (ROOT / 'nodefiles').rglob('*'):
        try:
            if path.is_file():
                total += path.stat().st_size
        except FileNotFoundError:  # solver removed its temporary node file
            pass
    return total


def guard():
    if available_memory() < 16 * GIB:
        raise RuntimeError('Less than 16 GiB RAM available; stopping for other users')
    if shutil.disk_usage(ROOT).free < 5 * GIB:
        raise RuntimeError('Less than 5 GiB disk space free')
    if node_size() > 2 * GIB:
        raise RuntimeError('Node files exceeded the 2 GiB cleanup threshold')


def restricted_child(memory_mb, cpu_seconds, parent_pid):
    # This executes before exec(), so imports, model construction and solving
    # are all subject to the kernel's per-process address-space ceiling.
    import resource
    import ctypes
    # Also stop numerical workers if their supervisor is killed unexpectedly.
    # The same rule protects children of the short infrastructure tests.
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0:  # PR_SET_PDEATHSIG
        raise OSError(ctypes.get_errno(), 'Cannot install parent-death safeguard')
    if os.getppid() != parent_pid:
        os._exit(1)
    memory = memory_mb * 1024 ** 2
    resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds))
    os.nice(10)


def terminate(children, grace=5):
    for process, _ in children:
        if process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
    deadline = time.monotonic() + grace
    while any(p.poll() is None for p, _ in children) and time.monotonic() < deadline:
        time.sleep(0.1)
    # Kill the entire owned groups, including any lingering descendants.
    for process, _ in children:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait()


def execute(jobs, cfg, deadline, cancelled=lambda: False):
    """Run (label, argv) jobs with bounded concurrency and process groups."""
    pending = list(jobs)
    active, outcomes = [], {}
    owner = os.getpid()
    try:
        while pending or active:
            if cancelled():
                raise InterruptedError('Stop requested')
            if time.monotonic() >= deadline:
                raise TimeoutError('Run time limit reached')
            guard()
            while pending and len(active) < cfg['WORKERS']:
                label, command = pending.pop(0)
                logfile = open(ROOT / 'logs' / (label + '.log'), 'a', buffering=1)
                logfile.write('\n=== %s: %s ===\n' % (time.ctime(), ' '.join(command)))
                seconds = max(1, math.ceil(deadline - time.monotonic()))
                try:
                    process = subprocess.Popen(
                        command, cwd=ROOT, stdout=logfile, stderr=subprocess.STDOUT,
                        start_new_session=True,
                        preexec_fn=lambda: restricted_child(
                            cfg['WORKER_MEMORY_MB'], seconds * cfg['THREADS'] + 10,
                            owner))
                except BaseException:
                    logfile.close()
                    raise
                print('Started %s (pid %d)' % (label, process.pid), flush=True)
                active.append((process, (label, logfile)))
            for process, (label, logfile) in active[:]:
                status = process.poll()
                if status is not None:
                    outcomes[label] = status
                    logfile.close()
                    active.remove((process, (label, logfile)))
                    print('Finished %s: exit %d' % (label, status), flush=True)
                    if status:
                        raise RuntimeError('%s failed (exit %d); see logs/%s.log'
                                           % (label, status, label))
            if active:
                time.sleep(0.25)
    finally:
        terminate(active)
        for _, (_, logfile) in active:
            logfile.close()
    return outcomes


def identity(pid):
    try:
        return Path('/proc/%d/stat' % pid).read_text().rsplit(')', 1)[1].split()[19]
    except (OSError, IndexError):
        return None


def read_state():
    try:
        return json.loads((ROOT / 'run.json').read_text())
    except (OSError, ValueError):
        return {}


def is_running(state):
    return (state.get('status') == 'RUNNING' and state.get('identity') is not None
            and identity(state.get('pid', 0)) == state.get('identity'))


def write_state(state):
    temporary = ROOT / 'run.json.tmp'
    temporary.write_text(json.dumps(state, indent=2) + '\n')
    os.replace(temporary, ROOT / 'run.json')


def task_ids(path):
    keys = ('n', 'T', 'top', 'form', 'sym', 'cuts', 'lp', 'chunk', 'm', 'ms')
    result = set()
    for line in path.read_text().splitlines():
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        words = line.split()
        spec = dict(word.split('=', 1) for word in words[1:])
        result.add(words[0] + '|' + '|'.join(k + '=' + spec[k] for k in keys if k in spec))
    return result


def collect(merge=True):
    from gol import io_utils as io
    parts = sorted((ROOT / 'results' / 'milp_n6_rest').glob('part_*.csv'))
    if parts and merge:
        io.merge([str(p) for p in parts], str(ROOT / 'results' / 'milp_n6_rest.csv'))
    complete = True
    for job in ('dp_small', 'milp_n6_rest'):
        expected = task_ids(ROOT / 'tasks' / (job + '.txt'))
        path = ROOT / 'results' / (job + '.csv')
        latest = {}
        sources = parts if job == 'milp_n6_rest' and not merge else [path]
        for source in sources:
            if not source.exists():
                continue
            with source.open(newline='') as f:
                for row in csv.DictReader(f):
                    if row['method'] in ('milp', 'dp'):
                        latest[row['task']] = row
        certified = {t for t, r in latest.items() if r['status'] == 'OPTIMAL'} & expected
        print('%s: %d/%d certified, %d unfinished or unresolved'
              % (job, len(certified), len(expected), len(expected - certified)), flush=True)
        complete &= certified == expected
    return complete


def probe():
    import resource
    import gurobipy as gp
    import numpy
    cfg = configuration()
    assert resource.getrlimit(resource.RLIMIT_AS)[1] <= 3072 * 1024 ** 2
    with gp.Model() as model:
        required = {'SoftMemLimit': 1.0, 'MemLimit': 1.5, 'NodefileStart': 0.25,
                    'Threads': 1, 'TimeLimit': 3600.0}
        for name, expected in required.items():
            actual = getattr(model.Params, name)
            if actual != expected:
                raise RuntimeError('gurobi.env: %s is %s, expected %s'
                                   % (name, actual, expected))
        if Path(model.Params.NodefileDir).resolve() != (ROOT / 'nodefiles').resolve():
            raise RuntimeError('NodefileDir is outside this run')
        model.Params.Threads = cfg['THREADS']
        model.Params.TimeLimit = cfg['TIMELIMIT']
        model.addVar(obj=1)
        model.optimize()
    print('Linux hard memory limit and Gurobi settings verified; numpy', numpy.__version__)


def run(check_only=False):
    import fcntl
    cfg = configuration()
    lock = (ROOT / 'run.lock').open('a')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise RuntimeError('This folder already has a running job')
    for directory in ('results', 'logs', 'nodefiles', 'results/milp_n6_rest'):
        (ROOT / directory).mkdir(parents=True, exist_ok=True)
    if (ROOT / 'nodefiles').resolve().parent != ROOT:
        raise RuntimeError('nodefiles must be a local directory, not an external symlink')
    stopped = []
    signal.signal(signal.SIGTERM, lambda *_: stopped.append(True))
    signal.signal(signal.SIGINT, lambda *_: stopped.append(True))
    state = {'status': 'RUNNING', 'pid': os.getpid(), 'identity': identity(os.getpid()),
             'started': time.ctime(), 'settings': cfg}
    write_state(state)
    deadline = time.monotonic() + cfg['MAX_HOURS'] * 3600
    sequential = dict(cfg, WORKERS=1)
    code = 1
    try:
        print('Shared-workstation limits:', cfg, flush=True)
        execute([('0_safety_tests', [sys.executable, '-u', '-m', 'unittest',
                                    '-v', 'test_workstation'])],
                sequential, min(deadline, time.monotonic() + 120), lambda: bool(stopped))
        # All numerical imports and validation solves run inside the same limits.
        execute([('0_gurobi', [sys.executable, '-u', __file__, 'probe'])],
                sequential, min(deadline, time.monotonic() + 120), lambda: bool(stopped))
        execute([('0_tests', [sys.executable, '-u', '-m', 'tests.test_gol'])],
                sequential, min(deadline, time.monotonic() + 3600), lambda: bool(stopped))
        if check_only:
            state['status'] = 'CHECKED'
            code = 0
        else:
            execute([('dp_small', [sys.executable, '-u', 'run.py', 'worker',
                     '--tasks', 'tasks/dp_small.txt', '--out', 'results/dp_small.csv'])],
                    sequential, min(deadline, time.monotonic() + 7200), lambda: bool(stopped))
            jobs = []
            # Stable files per task: lowering concurrency on restart must not
            # move tasks between shards or mix old/new records across files.
            task_count = len(task_ids(ROOT / 'tasks/milp_n6_rest.txt'))
            for k in range(task_count):
                jobs.append(('milp_n6_rest_%d' % k, [sys.executable, '-u', 'run.py',
                    'worker', '--tasks', 'tasks/milp_n6_rest.txt', '--shard', str(k),
                    '--of', str(task_count), '--threads', str(cfg['THREADS']),
                    '--time-limit', str(cfg['TIMELIMIT']), '--retry-feasible',
                    '--out', 'results/milp_n6_rest/part_%d.csv' % k]))
            execute(jobs, cfg, deadline, lambda: bool(stopped))
            complete = collect()
            state['status'] = 'COMPLETED' if complete else 'INCOMPLETE'
            code = 0 if complete else 2
    except BaseException as exc:
        state['status'] = 'STOPPED' if isinstance(exc, InterruptedError) else 'FAILED'
        state['reason'] = str(exc)
        print(state['status'] + ': ' + str(exc), flush=True)
        try:
            collect()
        except Exception as merge_error:
            print('Collection failed:', merge_error, flush=True)
    finally:
        # All owned child process groups have been reaped by execute().
        shutil.rmtree(ROOT / 'nodefiles')
        state['finished'] = time.ctime()
        write_state(state)
        lock.close()
    print('Final status:', state['status'], '- copy results/, logs/, report.log and run.json',
          flush=True)
    return code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['launch', 'run', 'check', 'probe', 'status', 'stop'])
    action = parser.parse_args().action
    os.chdir(ROOT)
    if not sys.platform.startswith('linux'):
        parser.error('Run this package on Linux; refusing to omit OS memory limits')
    for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
        os.environ[key] = '1'
    configuration()  # reject zero, unlimited or excessive overrides before launch
    if action == 'probe':
        probe()
        return 0
    if action in ('run', 'check'):
        return run(action == 'check')
    state = read_state()
    if action == 'status':
        print(json.dumps(state, indent=2))
        print('Supervisor alive:', is_running(state))
        print('Available RAM: %.1f GiB' % (available_memory() / GIB))
        collect(merge=False)
    elif action == 'stop':
        if is_running(state):
            os.kill(state['pid'], signal.SIGTERM)
            print('Stop requested; workers get a five-second grace period before KILL.')
        else:
            print('No live supervisor for this run.')
    else:
        if is_running(state):
            raise RuntimeError('Already running; use bash status.sh')
        logfile = open(ROOT / 'report.log', 'a')
        process = subprocess.Popen([sys.executable, '-u', __file__, 'run'],
                                   stdout=logfile, stderr=subprocess.STDOUT,
                                   stdin=subprocess.DEVNULL, start_new_session=True)
        logfile.close()
        time.sleep(1)
        if process.poll() is not None:
            raise RuntimeError('Launch failed; see report.log')
        print('Started pid %d; use bash status.sh, bash stop.sh or tail -f report.log'
              % process.pid)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, RuntimeError, OSError) as error:
        sys.exit(str(error))
