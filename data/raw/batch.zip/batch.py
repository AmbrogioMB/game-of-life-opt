"""Detached, bounded workstation refresh. Standard library supervisor only."""
import argparse
import csv
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import urllib.request

import workstation as ws

ROOT = Path(__file__).resolve().parent
GROUPS = ('brute_small', 'milp_xval', 'milp_n6', 'dp_small', 'dp_large')


def notify(message, priority='default'):
    """Bounded, best-effort delivery; no network operation runs inside a worker."""
    topic = os.environ.get('NTFY_TOPIC', (ROOT / 'NTFY_TOPIC.txt').read_text().strip())
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', topic):
        raise ValueError('Invalid NTFY_TOPIC')
    record = {'time': time.ctime(), 'message': message, 'delivered': False}
    request = urllib.request.Request('https://ntfy.sh/' + topic,
        data=message.encode('utf-8'), method='POST',
        headers={'Title': 'Game of Life workstation', 'Priority': priority,
                 'Content-Type': 'text/plain; charset=utf-8'})
    try:
        with urllib.request.urlopen(request, timeout=5) as response:
            record['delivered'] = response.status == 200
    except Exception as error:
        record['error'] = str(error)
        print('ntfy delivery failed:', error, flush=True)
    with (ROOT / 'notifications.jsonl').open('a') as stream:
        stream.write(json.dumps(record) + '\n')
    return record['delivered']


def task_lines(group):
    return [line.strip() for line in (ROOT / 'tasks' / (group + '.txt')).read_text().splitlines()
            if line.strip() and not line.lstrip().startswith('#')]


def progress(merge=False):
    from gol import io_utils as io
    counts = {}
    for group in GROUPS:
        parts = sorted((ROOT / 'results' / group).glob('part_*.csv'))
        if merge and parts:
            io.merge([str(p) for p in parts], str(ROOT / 'results' / (group + '.csv')))
        expected = ws.task_ids(ROOT / 'tasks' / (group + '.txt'))
        latest = {}
        for part in parts:
            with part.open(newline='') as stream:
                for row in csv.DictReader(stream):
                    if row.get('method') == row.get('task', '').split('|')[0]:
                        latest[row['task']] = row
        done = sum(latest.get(t, {}).get('status') == 'OPTIMAL' for t in expected)
        counts[group] = [done, len(expected)]
    return counts


def describe(counts):
    return '; '.join('%s %d/%d' % (name, *count) for name, count in counts.items())


def manifest_check():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    for name, expected in manifest.items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('Package file changed: ' + name)


def run(check_only=False):
    cfg = ws.configuration()
    # Timings are taken with no other numerical job in THIS package running.
    cfg['WORKERS'] = 1
    lock = (ROOT / 'run.lock').open('a')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        lock.close()
        raise RuntimeError('This folder already has a running job')
    for directory in ('results', 'logs', 'nodefiles'):
        (ROOT / directory).mkdir(exist_ok=True)
    if (ROOT / 'nodefiles').resolve() != ROOT / 'nodefiles':
        lock.close()
        raise RuntimeError('nodefiles must not be an external symlink')
    stopped = []
    signal.signal(signal.SIGTERM, lambda *_: stopped.append(True))
    signal.signal(signal.SIGINT, lambda *_: stopped.append(True))
    state = dict(status='RUNNING', pid=os.getpid(), identity=ws.identity(os.getpid()),
                 started=time.ctime(), settings=cfg, stage='starting')
    ws.write_state(state)
    started = time.monotonic()
    deadline = started + cfg['MAX_HOURS'] * 3600
    last_update = [started]
    code = 1

    def cancelled():
        if stopped:
            return True
        if time.monotonic() - last_update[0] >= 1800:
            last_update[0] = time.monotonic()
            counts = progress()
            state['progress'] = counts
            state['updated'] = time.ctime()
            ws.write_state(state)
            notify('Still running: %s. Elapsed %.1f h. %s' %
                   (state['stage'], (time.monotonic()-started)/3600, describe(counts)))
        return bool(stopped)

    def stage(label, commands, hours=None):
        state['stage'] = label
        state['updated'] = time.ctime()
        ws.write_state(state)
        notify('Starting ' + label)
        end = min(deadline, time.monotonic() + hours*3600) if hours else deadline
        ws.execute(commands, cfg, end, cancelled)
        notify('Finished ' + label + '. ' + describe(progress()))

    try:
        manifest_check()
        notify('Run started. Serial jobs, %d solver thread(s), 3 GiB per worker, '
               '%d h overall limit. Checks run first.' % (cfg['THREADS'], cfg['MAX_HOURS']))
        stage('preflight', [
            ('0_safety', [sys.executable, '-u', '-m', 'unittest', '-v',
                          'test_workstation', 'test_refresh']),
            ('0_environment', [sys.executable, '-u', 'refresh_jobs.py', 'environment']),
            ('0_gurobi', [sys.executable, '-u', 'workstation.py', 'probe']),
            ('0_structure', [sys.executable, '-u', 'run.py', 'check']),
            ('0_numerical_tests', [sys.executable, '-u', '-m', 'tests.test_gol'])], hours=1)
        if check_only:
            state['status'], code = 'CHECKED', 0
        else:
            stage('C++ exhaustive m=8', [
                ('exact_m8', [sys.executable, '-u', 'refresh_jobs.py', 'exact'])], hours=0.5)
            # Small tasks first. Large DP tasks are separate so earlier results survive.
            for group in GROUPS:
                jobs = []
                lines = task_lines(group)
                for index, _ in enumerate(lines):
                    jobs.append(('%s_%d' % (group, index), [sys.executable, '-u',
                        'run.py', 'worker', '--tasks', 'tasks/' + group + '.txt',
                        '--shard', str(index), '--of', str(len(lines)),
                        '--threads', str(cfg['THREADS']), '--time-limit', str(cfg['TIMELIMIT']),
                        '--retry-feasible', '--out', 'results/%s/part_%03d.csv' % (group, index)]))
                if group == 'dp_large':
                    for index, job in enumerate(jobs):
                        stage(lines[index], [job])
                else:
                    stage(group, jobs)
                progress(merge=True)
            stage('verify returned results', [
                ('audit', [sys.executable, '-u', 'refresh_jobs.py', 'audit'])], hours=0.5)
            counts = progress(merge=True)
            state['progress'] = counts
            complete = all(done == total for done, total in counts.values())
            state['status'], code = ('COMPLETED', 0) if complete else ('INCOMPLETE', 2)
    except BaseException as error:
        state['status'] = 'STOPPED' if isinstance(error, InterruptedError) else 'FAILED'
        state['reason'] = str(error)
        print(state['status'] + ': ' + str(error), flush=True)
        try:
            state['progress'] = progress(merge=True)
        except Exception as collection_error:
            print('Collection failed:', collection_error, flush=True)
    finally:
        # ws.execute has stopped/reaped its owned process groups before returning.
        node_directory = ROOT / 'nodefiles'
        if node_directory.exists() and node_directory.resolve() == ROOT / 'nodefiles':
            shutil.rmtree(node_directory)
        state['finished'] = time.ctime()
        state['elapsed_hours'] = round((time.monotonic()-started)/3600, 4)
        ws.write_state(state)
        try:
            notify('%s after %.2f h. %s. %s Copy back the entire folder.' %
                   (state['status'], state['elapsed_hours'], state.get('reason', ''),
                    describe(state.get('progress', {}))),
                   'high' if state['status'] in ('FAILED', 'STOPPED', 'INCOMPLETE') else 'default')
        finally:
            lock.close()
    print('Final status:', state['status'], flush=True)
    return code


def launch():
    if ws.is_running(ws.read_state()):
        raise RuntimeError('Already running; use bash status.sh')
    with (ROOT / 'report.log').open('a') as log:
        child = subprocess.Popen([sys.executable, '-u', __file__, 'run'],
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
            cwd=ROOT, start_new_session=True)
    time.sleep(1)
    if child.poll() is not None:
        raise RuntimeError('Launch exited; inspect report.log and run.json')
    print('Started detached supervisor pid %d. You can close this terminal.' % child.pid)
    print('Subscribe: https://ntfy.sh/' + (ROOT / 'NTFY_TOPIC.txt').read_text().strip())
    print('Use bash status.sh or bash stop.sh; results and logs survive logout.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['launch', 'run', 'check', 'status', 'stop', 'notify-test'])
    action = parser.parse_args().action
    os.chdir(ROOT)
    if not sys.platform.startswith('linux'):
        parser.error('Run this package on Linux; OS limits are mandatory')
    if sys.version_info < (3, 10):
        parser.error('Python 3.10 or later is required')
    for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
        os.environ[key] = '1'
    ws.configuration()
    if action == 'launch':
        launch()
    elif action in ('run', 'check'):
        return run(action == 'check')
    elif action == 'notify-test':
        return 0 if notify('Notification test: workstation can reach this topic.') else 1
    elif action == 'status':
        state = ws.read_state()
        print(json.dumps(state, indent=2))
        print('Supervisor alive:', ws.is_running(state))
        print(describe(progress()))
        print('Available RAM: %.1f GiB' % (ws.available_memory()/ws.GIB))
    elif action == 'stop':
        state = ws.read_state()
        if ws.is_running(state):
            os.kill(state['pid'], signal.SIGTERM)
            print('Stop requested. Workers receive TERM, then KILL after five seconds.')
        else:
            print('No live supervisor for this folder.')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, RuntimeError, OSError) as error:
        sys.exit(str(error))
