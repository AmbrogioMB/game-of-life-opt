"""Small Linux integration tests; no solver, large arrays or long jobs."""
import csv
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import workstation as ws


@unittest.skipUnless(sys.platform.startswith('linux'), 'Linux resource/process tests')
class SupervisorTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name)
        for name in ('logs', 'results/milp_n6_rest', 'nodefiles', 'tasks'):
            (self.root / name).mkdir(parents=True, exist_ok=True)
        for job, line in [('dp_small', 'dp n=3 T=1 top=s'),
                          ('milp_n6_rest', 'milp n=6 T=2 top=s')]:
            (self.root / 'tasks' / (job + '.txt')).write_text(line + '\n')
        self.root_patch = patch.object(ws, 'ROOT', self.root)
        self.root_patch.start()
        self.cfg = dict(WORKERS=2, THREADS=1, WORKER_MEMORY_MB=128,
                        TIMELIMIT=10, MAX_HOURS=1)

    def tearDown(self):
        self.root_patch.stop()
        self.directory.cleanup()

    def execute(self, code, seconds=5):
        with patch.object(ws, 'guard'):
            return ws.execute([('small', [sys.executable, '-c', code])],
                              self.cfg, time.monotonic() + seconds)

    def test_hard_address_space_limit(self):
        code = '''import resource
assert resource.getrlimit(resource.RLIMIT_AS) == (128*1024**2, 128*1024**2)
try:
    value = bytearray(256*1024**2)
except MemoryError:
    pass
else:
    raise AssertionError('kernel did not reject oversized allocation')
'''
        self.assertEqual(self.execute(code), {'small': 0})

    def test_worker_failure_stops_sibling(self):
        jobs = [('bad', [sys.executable, '-c', 'import time; time.sleep(.2); raise SystemExit(7)']),
                ('other', [sys.executable, '-c', 'import time; time.sleep(60)'])]
        start = time.monotonic()
        with patch.object(ws, 'guard'), self.assertRaisesRegex(RuntimeError, 'exit 7'):
            ws.execute(jobs, self.cfg, start + 10)
        self.assertLess(time.monotonic() - start, 7)

    def test_time_limit_kills_uncooperative_child(self):
        code = ('import signal,time; signal.signal(signal.SIGTERM, signal.SIG_IGN); '
                'time.sleep(60)')
        start = time.monotonic()
        with self.assertRaises(TimeoutError):
            self.execute(code, seconds=.5)
        self.assertLess(time.monotonic() - start, 8)

    def test_stop_cancels_job(self):
        with patch.object(ws, 'guard'), self.assertRaises(InterruptedError):
            ws.execute([('stop', [sys.executable, '-c', 'pass'])], self.cfg,
                       time.monotonic() + 10, cancelled=lambda: True)

    def test_low_memory_refuses_jobs(self):
        with patch.object(ws, 'available_memory', return_value=15 * ws.GIB):
            with self.assertRaisesRegex(RuntimeError, 'other users'):
                ws.guard()

    def test_no_unlimited_or_excessive_overrides(self):
        for key in ('WORKERS', 'THREADS', 'TIMELIMIT', 'MAX_HOURS', 'WORKER_MEMORY_MB'):
            for value in ('0', '-1', 'unlimited', '999999999'):
                with self.subTest(key=key, value=value), patch.dict(os.environ, {key: value}):
                    with self.assertRaises(ValueError):
                        ws.configuration()

    def test_collection_keeps_unresolved_run_incomplete(self):
        self.assertFalse(ws.collect())

    def test_failed_merge_is_not_success(self):
        part = self.root / 'results/milp_n6_rest/part_0.csv'
        part.write_text('method,task,status\n')
        with patch('gol.io_utils.merge', side_effect=OSError('disk full')):
            with self.assertRaisesRegex(OSError, 'disk full'):
                ws.collect()

    def fake_complete(self, jobs, *args, **kwargs):
        for label, _ in jobs:
            if label == 'dp_small':
                path = self.root / 'results/dp_small.csv'
                task = next(iter(ws.task_ids(self.root / 'tasks/dp_small.txt')))
                method = 'dp'
            elif label.startswith('milp_n6_rest'):
                path = self.root / 'results/milp_n6_rest/part_0.csv'
                task = next(iter(ws.task_ids(self.root / 'tasks/milp_n6_rest.txt')))
                method = 'milp'
            else:
                continue
            with path.open('w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=['method', 'task', 'status'])
                writer.writeheader()
                writer.writerow(dict(method=method, task=task, status='OPTIMAL'))
        return {}

    def test_full_orchestration_reports_real_completion(self):
        with patch.object(ws, 'execute', side_effect=self.fake_complete), \
             patch.object(ws.signal, 'signal'), patch.object(ws, 'configuration', return_value=self.cfg):
            self.assertEqual(ws.run(), 0)
        self.assertEqual(json.loads((self.root / 'run.json').read_text())['status'], 'COMPLETED')
        self.assertFalse((self.root / 'nodefiles').exists())

    def test_failed_worker_cannot_report_completion(self):
        with patch.object(ws, 'execute', side_effect=RuntimeError('worker failed')), \
             patch.object(ws.signal, 'signal'), patch.object(ws, 'configuration', return_value=self.cfg):
            self.assertEqual(ws.run(), 1)
        state = json.loads((self.root / 'run.json').read_text())
        self.assertEqual(state['status'], 'FAILED')
        self.assertIn('worker failed', state['reason'])

    def test_stale_pid_is_not_signalled(self):
        with patch.object(ws, 'identity', return_value='new-process'):
            self.assertFalse(ws.is_running(dict(status='RUNNING', pid=1234, identity='old-process')))

    def test_shell_entrypoints_parse(self):
        package = Path(__file__).resolve().parent
        for path in package.glob('*.sh'):
            with self.subTest(script=path.name):
                subprocess.run(['bash', '-n', str(path)], check=True, capture_output=True)

    def test_worker_dies_with_its_parent(self):
        package = str(Path(__file__).resolve().parent)
        marker = self.root / 'child.pid'
        code = '''import os,subprocess,sys,time
sys.path.insert(0, sys.argv[1])
import workstation
owner = os.getpid()
child = subprocess.Popen([sys.executable, '-c',
    "import os,time,pathlib; pathlib.Path(%r).write_text(str(os.getpid())); time.sleep(60)" % sys.argv[2]],
    preexec_fn=lambda: workstation.restricted_child(128, 10, owner))
deadline = time.monotonic() + 3
while not os.path.exists(sys.argv[2]) and time.monotonic() < deadline:
    time.sleep(.02)
os._exit(0)
'''
        subprocess.run([sys.executable, '-c', code, package, str(marker)], check=True, timeout=5)
        pid = int(marker.read_text())
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            try:
                state = Path('/proc/%d/stat' % pid).read_text().rsplit(')', 1)[1].split()[0]
            except FileNotFoundError:
                return
            if state == 'Z':  # killed; waiting for the init process to reap it
                return
            time.sleep(.02)
        self.fail('worker survived its supervisor')

    def test_task_files_do_not_change_with_concurrency(self):
        path = self.root / 'tasks/milp_n6_rest.txt'
        path.write_text(''.join('milp n=6 T=2 top=%s\n' % top for top in 'stm'))
        assignments = []
        def record(jobs, cfg, *args):
            commands = [command for label, command in jobs if label.startswith('milp_n6_rest')]
            if commands:
                assignments.append(commands)
            return {}
        for concurrency in (1, 2):
            cfg = dict(self.cfg, WORKERS=concurrency)
            with patch.object(ws, 'execute', side_effect=record), \
                 patch.object(ws, 'collect', return_value=True), \
                 patch.object(ws.signal, 'signal'), \
                 patch.object(ws, 'configuration', return_value=cfg):
                self.assertEqual(ws.run(), 0)
        self.assertEqual(len(assignments[0]), 3)
        self.assertEqual(assignments[0], assignments[1])


if __name__ == '__main__':
    unittest.main()
