"""Restricted worker-side environment capture, C++ verification and result audit."""
import csv
from fractions import Fraction
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import random
import resource
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
GROUPS = ('brute_small', 'milp_xval', 'milp_n6', 'dp_small', 'dp_large')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def save(name, data):
    target = ROOT / 'results' / name
    temporary = target.with_suffix(target.suffix + '.tmp')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    os.replace(temporary, target)


def environment():
    import gurobipy as gp
    import numpy as np
    compiler = shutil.which('g++')
    require(compiler is not None, 'g++ (C++17) is required')
    memory = resource.getrlimit(resource.RLIMIT_AS)
    require(0 < memory[1] <= 3072*1024**2, 'Worker hard memory ceiling missing')
    record = dict(time=time.ctime(), host=platform.node(), platform=platform.platform(),
        python=sys.version, executable=sys.executable, numpy=np.__version__,
        gurobipy=importlib.metadata.version('gurobipy'), gurobi=gp.gurobi.version(),
        cpuinfo=Path('/proc/cpuinfo').read_text(), meminfo=Path('/proc/meminfo').read_text(),
        threads={k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS',
                                               'MKL_NUM_THREADS','NUMEXPR_NUM_THREADS')},
        hard_address_space_bytes=memory[1],
        compiler=subprocess.check_output([compiler, '--version'], text=True),
        gurobi_env=(ROOT/'gurobi.env').read_text(),
        manifest_sha256=hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest())
    # Verify the real compiler, not merely its version string, before long jobs.
    subprocess.run([compiler, '-O3', '-std=c++17', 'exact_m8.cpp', '-o', 'results/exact_m8'],
                   cwd=ROOT, check=True, timeout=120)
    save('environment.json', record)
    print('Environment and compiler verified:', sys.version, np.__version__, gp.gurobi.version())


def exact():
    from gol import simulate as sim
    executable = ROOT / 'results/exact_m8'
    require(executable.is_file(), 'Preflight did not build exact_m8')
    output = subprocess.check_output([str(executable)], text=True, timeout=300)
    result = json.loads(output)
    expected = dict(n=6, T=3, topology='s', m=8, status='OPTIMAL',
                    method='exhaustive-fixed-m', boards_scanned=math.comb(36,8), final_cells=22)
    require(all(result.get(k) == v for k,v in expected.items()), 'Unexpected exact_m8 result')
    neighbours = sim.neighbour_lists(6, 's')
    seed = int(result['seed'])
    require(sim.popcount(seed) == 8 and 0 <= seed < (1 << 36), 'Invalid m=8 seed')
    require(sim.popcount(sim.evolve(seed, neighbours, 6, 3)) == 22, 'Invalid C++ witness')
    rng = random.Random(20261031)
    boards = [0, (1<<36)-1] + [1<<i for i in range(36)]
    boards += [rng.getrandbits(36) for _ in range(64)]
    boards += [sum(1<<i for i in rng.sample(range(36),8)) for _ in range(64)]
    comparisons = 0
    for seed in boards:
        for _ in range(3):
            expected_step = sim.step(seed, neighbours, 6)
            actual = int(subprocess.check_output([str(executable), '--step', str(seed)], text=True))
            require(actual == expected_step, 'C++/Python simulator mismatch')
            comparisons += 1
            seed = expected_step
    result['python_step_comparisons'] = comparisons
    result['source_sha256'] = hashlib.sha256((ROOT/'exact_m8.cpp').read_bytes()).hexdigest()
    save('exact_m8.json', result)
    print('Exhaustive m=8 result and %d Python comparisons verified' % comparisons)


def check_witness(row):
    from gol import simulate as sim
    n, steps = int(row['n']), int(row['T'])
    seed = sim.decode(n, row['board'])
    require(0 < seed < 1 << (n*n), 'Invalid witness seed')
    initial = sim.popcount(seed)
    final = sim.popcount(sim.evolve(seed, sim.neighbour_lists(n, row['topology']), n, steps))
    rate = Fraction(final, initial)
    require(math.isclose(float(rate), float(row['rate']), abs_tol=1e-12), 'Witness rate mismatch')
    if row.get('numerator'):
        require(rate == Fraction(int(row['numerator']), int(row['denominator'])),
                'DP counts disagree with witness')
    if row.get('final_cells'):
        require(final == int(row['final_cells']) and initial == int(row['m']),
                'Witness population mismatch')
    return rate


def audit():
    import workstation as ws
    from gol import bounds
    from gol import io_utils as io
    expected_rates = json.loads((ROOT/'reference/expected_rates.json').read_text())
    checked, unresolved, missing = [], [], []
    hashes = {}
    for group in GROUPS:
        parts = sorted((ROOT/'results'/group).glob('part_*.csv'))
        path = ROOT/'results'/(group+'.csv')
        io.merge([str(p) for p in parts], str(path))
        hashes[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
        with path.open(newline='') as stream:
            rows = list(csv.DictReader(stream))
        expected = sorted(ws.task_ids(ROOT/'tasks'/(group+'.txt')))
        summary = {r['task']:r for r in rows if r['method'] in ('dp','brute','milp')}
        require(set(summary) <= set(expected), 'Unexpected result task')
        for task in expected:
            if task not in summary:
                missing.append(task)
                continue
            row = summary[task]
            if row['status'] != 'OPTIMAL':
                unresolved.append(task)
                continue
            rate = check_witness(row)
            key = '%s,%s,%s' % (row['n'], row['T'], row['topology'])
            require(rate == Fraction(expected_rates[key]), 'Changed optimum: ' + task)
            if row['method'] == 'milp':
                populations = [r for r in rows if r['task']==task and r['method']=='milp-m']
                status, _, open_populations = bounds.certify_sweep(int(row['n']), int(row['T']), populations)
                require(status=='OPTIMAL' and not open_populations, 'Sweep summary not certified: '+task)
                for population in populations:
                    if population.get('board'):
                        check_witness(population)
            elif row['method'] == 'brute':
                require(row['chunk']=='0' and row['chunks']=='1', 'Incomplete enumeration coverage')
            checked.append(dict(task=task, rate=str(rate)))
    # The other populations in the combined proof were already certified on the
    # workstation. Keep that imported evidence separate from this run's output.
    source = ROOT/'reference/workstation_milp.csv'
    task = 'milp|n=6|T=3|top=s|form=bigm|sym=1|cuts=1'
    with source.open(newline='') as stream:
        populations = [r for r in csv.DictReader(stream) if r['task']==task and r['method']=='milp-m']
    result = json.loads((ROOT/'results/exact_m8.json').read_text())
    require(result['boards_scanned']==math.comb(36,8) and result['final_cells']==22,
            'Missing exact m=8 certificate')
    exact_row = dict(m=8, status='OPTIMAL', final_cells=22, bound=22, rate=22/8)
    populations = [r for r in populations if int(r['m'])!=8] + [exact_row]
    status, upper, open_populations = bounds.certify_sweep(6,3,populations)
    require(status=='OPTIMAL' and not open_populations and upper==Fraction(20,7),
            'Combined workstation certificate failed')
    hashes[str(source.relative_to(ROOT))] = hashlib.sha256(source.read_bytes()).hexdigest()
    report = dict(status='VERIFIED' if not missing and not unresolved else 'INCOMPLETE',
                  checked=checked, missing=missing, unresolved=unresolved,
                  combined_square_n6_T3=dict(status=status, rate=str(upper)), hashes=hashes)
    save('audit.json', report)
    print('Audit:', report['status'], len(checked), 'certified task witnesses checked')


if __name__ == '__main__':
    os.chdir(ROOT)
    {'environment': environment, 'exact': exact, 'audit': audit}[sys.argv[1]]()
