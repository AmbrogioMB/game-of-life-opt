#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
source ./settings.sh
exec "$PYTHON" -u batch.py launch
